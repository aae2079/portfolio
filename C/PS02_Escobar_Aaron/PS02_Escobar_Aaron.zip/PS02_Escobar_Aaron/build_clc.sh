gcc -o clc cmd_line_calc.c
