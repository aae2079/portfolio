#!/bin/bash
gcc -Wall -o sort_struct sort_main.c sort_struct.c
