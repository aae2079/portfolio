#!/bin/bash
gcc -Wall -o search_struct search.c
